import mongoose from 'mongoose';
import ApiError from '../../utils/ApiError.js';
import ApiResponse from '../../utils/ApiResponse.js';
import { ExpenseType, IncomeType, PaymentMode } from './masters.model.js';
import Transaction from './model.js';
import {
    createTransactionSchema,
    monthQuerySchema,
    transactionToDatabase,
    transactionToResponse,
    updateTransactionSchema,
} from './transaction.schema.js';

const getIssues = (error) => error.issues.map(({ path, code, message }) => ({
    path,
    code,
    message,
}));

const parseOrThrow = (schema, value, message) => {
    const parsed = schema.safeParse(value);
    if (!parsed.success) {
        throw new ApiError(400, message, getIssues(parsed.error));
    }
    return parsed.data;
};

const assertMasterBelongsToUser = async (Model, id, userId, label) => {
    const exists = await Model.exists({ _id: id, userId });
    if (!exists) {
        throw new ApiError(400, `${label} does not belong to the authenticated user.`);
    }
};

const validateReferences = async (data, userId) => {
    const checks = [
        assertMasterBelongsToUser(PaymentMode, data.paymentModeId, userId, 'Payment mode'),
    ];
    if (data.type === 'income') {
        checks.push(assertMasterBelongsToUser(IncomeType, data.incomeTypeId, userId, 'Income type'));
    } else {
        checks.push(assertMasterBelongsToUser(ExpenseType, data.expenseTypeId, userId, 'Expense type'));
    }
    await Promise.all(checks);
};

const monthRange = (month) => {
    const [year, monthNumber] = month.split('-').map(Number);
    return {
        start: new Date(Date.UTC(year, monthNumber - 1, 1)),
        end: new Date(Date.UTC(year, monthNumber, 1)),
    };
};

const selectedMonth = (month) => month ?? new Date().toISOString().slice(0, 7);

const transactionFilter = (userId, month) => {
    const filter = { userId };
    if (month) {
        const { start, end } = monthRange(month);
        filter.transactionDate = { $gte: start, $lt: end };
    }
    return filter;
};

class TransactionController {
    static async list(req, res) {
        const { month } = parseOrThrow(monthQuerySchema, req.query, 'Invalid month filter.');
        const transactions = await Transaction.find(transactionFilter(req.user.id, month))
            .sort({ transactionDate: -1, _id: -1 });
        res.status(200).json(new ApiResponse(
            200,
            transactions.map(transactionToResponse),
            'Transactions retrieved successfully',
        ));
    }

    static async create(req, res) {
        const data = parseOrThrow(createTransactionSchema, req.body, 'Invalid transaction data.');
        await validateReferences(data, req.user.id);
        const transaction = await Transaction.create({
            ...transactionToDatabase(data),
            userId: req.user.id,
        });
        res.status(201).json(new ApiResponse(
            201,
            transactionToResponse(transaction),
            'Transaction created successfully',
        ));
    }

    static async update(req, res) {
        if (!mongoose.isValidObjectId(req.params.id)) {
            throw new ApiError(400, 'Invalid transaction ID.');
        }
        const updates = parseOrThrow(updateTransactionSchema, req.body, 'Invalid transaction data.');
        const transaction = await Transaction.findOne({ _id: req.params.id, userId: req.user.id });
        if (!transaction) {
            throw new ApiError(404, 'Transaction was not found.');
        }

        const current = {
            type: transaction.type,
            expenseTypeId: transaction.expenseTypeId?.toString(),
            incomeTypeId: transaction.incomeTypeId?.toString(),
            paymentModeId: transaction.paymentModeId.toString(),
            amount: transaction.amountPaise / 100,
            transactionDate: transaction.transactionDate.toISOString(),
            note: transaction.note,
        };
        const mergedFields = { ...current, ...updates };
        if (updates.type === 'income' && current.type !== 'income') {
            mergedFields.expenseTypeId = undefined;
        }
        if (updates.type === 'expense' && current.type !== 'expense') {
            mergedFields.incomeTypeId = undefined;
        }
        const merged = parseOrThrow(
            createTransactionSchema,
            mergedFields,
            'Invalid transaction data.',
        );
        await validateReferences(merged, req.user.id);

        const databaseFields = transactionToDatabase(merged);
        transaction.type = databaseFields.type;
        transaction.expenseTypeId = databaseFields.expenseTypeId;
        transaction.incomeTypeId = databaseFields.incomeTypeId;
        transaction.paymentModeId = databaseFields.paymentModeId;
        transaction.amountPaise = databaseFields.amountPaise;
        transaction.transactionDate = databaseFields.transactionDate;
        transaction.note = databaseFields.note;
        await transaction.save();

        res.status(200).json(new ApiResponse(
            200,
            transactionToResponse(transaction),
            'Transaction updated successfully',
        ));
    }

    static async remove(req, res) {
        if (!mongoose.isValidObjectId(req.params.id)) {
            throw new ApiError(400, 'Invalid transaction ID.');
        }
        const transaction = await Transaction.findOneAndDelete({
            _id: req.params.id,
            userId: req.user.id,
        });
        if (!transaction) {
            throw new ApiError(404, 'Transaction was not found.');
        }
        res.status(200).json(new ApiResponse(200, {}, 'Transaction deleted successfully'));
    }

    static async summary(req, res) {
        const { month: requestedMonth } = parseOrThrow(
            monthQuerySchema,
            req.query,
            'Invalid month filter.',
        );
        const month = selectedMonth(requestedMonth);
        const [monthly, totals] = await Promise.all([
            Transaction.aggregate([
                { $match: { userId: new mongoose.Types.ObjectId(req.user.id) } },
                {
                    $group: {
                        _id: {
                            $dateToString: {
                                format: '%Y-%m',
                                date: '$transactionDate',
                                timezone: 'UTC',
                            },
                        },
                        incomePaise: {
                            $sum: {
                                $cond: [{ $eq: ['$type', 'income'] }, '$amountPaise', 0],
                            },
                        },
                        expensePaise: {
                            $sum: {
                                $cond: [{ $eq: ['$type', 'expense'] }, '$amountPaise', 0],
                            },
                        },
                    },
                },
                { $sort: { _id: 1 } },
            ]),
            Transaction.aggregate([
                { $match: { userId: new mongoose.Types.ObjectId(req.user.id) } },
                {
                    $group: {
                        _id: null,
                        incomePaise: {
                            $sum: {
                                $cond: [{ $eq: ['$type', 'income'] }, '$amountPaise', 0],
                            },
                        },
                        expensePaise: {
                            $sum: {
                                $cond: [{ $eq: ['$type', 'expense'] }, '$amountPaise', 0],
                            },
                        },
                    },
                },
            ]),
        ]);

        const monthTotals = monthly.find(({ _id }) => _id === month) ?? {
            incomePaise: 0,
            expensePaise: 0,
        };
        const allTimeTotals = totals[0] ?? { incomePaise: 0, expensePaise: 0 };
        const data = {
            month,
            monthlyIncome: monthTotals.incomePaise / 100,
            monthlyExpense: monthTotals.expensePaise / 100,
            monthlyBalance: (monthTotals.incomePaise - monthTotals.expensePaise) / 100,
            totalIncome: allTimeTotals.incomePaise / 100,
            totalExpense: allTimeTotals.expensePaise / 100,
            totalBalance: (allTimeTotals.incomePaise - allTimeTotals.expensePaise) / 100,
            currency: 'INR',
            months: monthly.map(({ _id, incomePaise, expensePaise }) => ({
                month: _id,
                income: incomePaise / 100,
                expense: expensePaise / 100,
                balance: (incomePaise - expensePaise) / 100,
                currency: 'INR',
            })),
        };

        res.status(200).json(new ApiResponse(200, data, 'Transaction summary retrieved successfully'));
    }
}

export default TransactionController;
