import { Router } from 'express';
import {
    ExpenseTypeController,
    IncomeTypeController,
    PaymentModeController,
} from './masters.controller.js';

const router = Router();

const masterRoutes = [
    ['/expense-types', ExpenseTypeController],
    ['/income-types', IncomeTypeController],
    ['/payment-modes', PaymentModeController],
];

for (const [path, Controller] of masterRoutes) {
    router.get(path, Controller.list.bind(Controller));
    router.post(path, Controller.create.bind(Controller));
    router.patch(`${path}/:id`, Controller.update.bind(Controller));
    router.delete(`${path}/:id`, Controller.remove.bind(Controller));
}

export default router;
