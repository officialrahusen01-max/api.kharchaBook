import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true,
        trim: true,
        minlength: 2,
        maxlength: 100,
    },
    phoneNumber: {
        type: String,
        required: true,
        trim: true,
        unique: true,
    },
    email: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        maxlength: 254,
        unique: true,
    },
    gender: {
        type: String,
        required: true,
        trim: true,
        maxlength: 30,
    },
    dob: {
        type: Date,
        required: true,
    },
    profilePhoto: {
        type: String,
        trim: true,
        maxlength: 500,
        default: null,
    },
    passwordHash: {
        type: String,
        required: true,
        select: false,
    },
}, {
    timestamps: true,
    versionKey: false,
    toJSON: {
        transform: (document, result) => {
            result.id = result._id.toString();
            delete result._id;
            delete result.passwordHash;
            return result;
        },
    },
});

const User = mongoose.models.User || mongoose.model('User', userSchema);

export default User;
