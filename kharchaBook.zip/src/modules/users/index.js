import { Router } from 'express';
import authenticate from '../../middlewares/auth.js';
import UserController from './controller.js';
import { parseProfilePhoto } from './profilePhoto.js';

const router = Router();

router.use(authenticate)
    .get('/profile', UserController.getProfile)
    .put('/profile', UserController.updateProfile)
    .patch('/profile/photo', parseProfilePhoto, UserController.updateProfilePhoto)

export default router;
