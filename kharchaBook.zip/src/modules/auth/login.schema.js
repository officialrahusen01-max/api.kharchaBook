import { z } from 'zod';

const loginSchema = z.object({
    phoneNumber: z.string().trim().regex(/^\+?[1-9]\d{6,14}$/, 'Enter a valid phone number.'),
    password: z.string().regex(/^[0-9]{6}$/, 'Password must be exactly 6 digits.'),
}).strict();

export default loginSchema;
