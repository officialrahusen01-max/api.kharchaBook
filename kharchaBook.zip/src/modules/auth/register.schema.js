import { z } from 'zod';

const isValidPastDate = (value) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;

    const date = new Date(`${value}T00:00:00.000Z`);
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
    return !Number.isNaN(date.valueOf())
        && date.toISOString().slice(0, 10) === value
        && date < today;
};

const registerSchema = z.object({
    fullName: z.string().trim().min(2).max(100),
    phoneNumber: z.string().trim().regex(/^\+?[1-9]\d{6,14}$/, 'Enter a valid phone number.'),
    email: z.string().trim().pipe(z.email().max(254)).transform((value) => value.toLowerCase()),
    gender: z.string().trim().min(1).max(30),
    dob: z.string().refine(isValidPastDate, 'Enter a valid date of birth in YYYY-MM-DD format.'),
    password: z.string().regex(/^[0-9]{6}$/, 'Password must be exactly 6 digits.'),
}).strict();

export default registerSchema;
