import ApiError from '../utils/ApiError.js';

const requirePermission = (permission) => (req, res, next) => {
    if (!req.user) {
        next(new ApiError(401, 'Authentication is required.'));
        return;
    }

    if (!Array.isArray(req.user.permissions) || !req.user.permissions.includes(permission)) {
        next(new ApiError(403, 'You do not have permission to perform this action.'));
        return;
    }

    next();
};

export default requirePermission;
