# Kharcha Book API - Frontend Guide

This document describes the implemented authentication, profile, and finance APIs.
The API responses and field names below match the current backend.
Other route groups in the repository are not covered here because their functionality
has not been included in this frontend API handoff.

## Base URL

Set `API_BASE_URL` to the deployed backend origin (without a trailing slash), for example:

```text
https://your-api-host
```

All API paths below start with `/api/v1`. For local development, use the origin and
port configured for the backend.

## Common request and response format

Send JSON requests with:

```http
Content-Type: application/json
```

Successful JSON responses use this envelope:

```json
{
  "success": true,
  "message": "Operation successful",
  "data": {}
}
```

Errors use this shape; `details` is present when field validation details are available:

```json
{
  "success": false,
  "message": "Invalid request data.",
  "details": []
}
```

Use the returned HTTP status as well as `success` to determine the outcome.

## Access-token authentication

Protected routes require the access token in the `Authorization` header:

```http
Authorization: Bearer <accessToken>
```

The frontend should attach this header to every `/users/*` and `/transactions/*`
request, plus logout and account deletion. Registration, login, and refresh do not
require an access token. An access token expires after 3600 seconds (one hour).

Example:

```js
const response = await fetch(`${API_BASE_URL}/api/v1/users/profile`, {
  headers: {
    Authorization: `Bearer ${accessToken}`,
  },
});
const result = await response.json();
```

When a protected API returns `401`, refresh the access token with the refresh-token
flow below. If refresh also returns `401`, clear the local session and ask the user
to log in again.

## Authentication APIs

### Register

`POST /api/v1/auth/register` — public, no token.

Request:

```json
{
  "fullName": "Rahul Kumar",
  "phoneNumber": "+919876543210",
  "email": "rahul@example.com",
  "gender": "male",
  "dob": "1998-05-20",
  "password": "123456"
}
```

`dob` must be a valid past date in `YYYY-MM-DD` format. `password` must be exactly
six digits; leading zeroes are allowed. Registration does not upload a profile photo.
The email is normalized to lowercase.

Success: `201 Created`.

The response has the common envelope and returns the created public user in `data`
(`id`, `fullName`, `phoneNumber`, `email`, `gender`, `dob`, and `createdAt`). It does
not return tokens; log in after registration to obtain them.

### Login

`POST /api/v1/auth/login` — public, no token.

Request:

```json
{
  "phoneNumber": "+919876543210",
  "password": "123456"
}
```

By default, login returns the refresh token in the JSON body (recommended for a
mobile client). Save both tokens securely:

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "USER_ID",
      "fullName": "Rahul Kumar",
      "phoneNumber": "+919876543210",
      "email": "rahul@example.com",
      "gender": "male",
      "dob": "1998-05-20T00:00:00.000Z",
      "createdAt": "2026-10-15T08:00:00.000Z"
    },
    "accessToken": "ACCESS_TOKEN",
    "tokenType": "Bearer",
    "expiresIn": 3600,
    "refreshToken": "REFRESH_TOKEN"
  }
}
```

For web clients, request an HttpOnly refresh-token cookie instead:

```http
X-Refresh-Token-Transport: cookie
```

In cookie mode, the refresh token is not included in `data`; the browser receives it
as an HttpOnly cookie. Use `credentials: 'include'` with browser requests and enable
credentials in the frontend HTTP client. The backend currently allows credentialed
requests from `http://localhost:2000`, `http://localhost:3000`, and
`http://localhost:3001`; add the deployed frontend origin to backend CORS configuration
before using cookie mode in production.

Each login replaces the stored refresh-token record for that user. A refresh token
expires after 30 days.

### Refresh access token

`POST /api/v1/auth/refresh` — public, no access token required.

Mobile/body transport:

```json
{
  "refreshToken": "REFRESH_TOKEN"
}
```

The response contains a new `accessToken` and a rotated `refreshToken`. Replace both
stored values; the old refresh token is no longer valid.

Web/cookie transport: send no JSON body and make the request with
`credentials: 'include'`. The browser sends the refresh cookie and receives its rotated
replacement. The response body contains the new `accessToken` but not the refresh token.

Success response:

```json
{
  "success": true,
  "message": "Token refreshed successfully",
  "data": {
    "accessToken": "NEW_ACCESS_TOKEN",
    "tokenType": "Bearer",
    "expiresIn": 3600,
    "refreshToken": "NEW_REFRESH_TOKEN"
  }
}
```

The `refreshToken` field is omitted in cookie mode. A missing, invalid, or expired
refresh token returns `401`.

### Logout

`POST /api/v1/auth/logout` — access token required.

Send `Authorization: Bearer <accessToken>`. In body mode, include the current refresh
token:

```json
{
  "refreshToken": "REFRESH_TOKEN"
}
```

For cookie mode, send the request with `credentials: 'include'`; the backend clears
the refresh cookie. Logout returns `200` and revokes the supplied refresh token.

### Delete account

`DELETE /api/v1/auth/deleteAccount` — access token required.

Send `Authorization: Bearer <accessToken>`. No request body is needed. This permanently
deletes the user, their refresh token, profile photo, finance masters, and transactions.
Success response data is `{}`.

### OTP

`POST /api/v1/auth/otp` currently returns `501 Not implemented`. Do not build a
registration or sign-in flow that depends on OTP yet.

## User profile APIs

All profile routes require the access-token header.

### Get profile

`GET /api/v1/users/profile`

Success response `data` contains `id`, `fullName`, `phoneNumber`, `email`, `gender`,
`dob`, `profilePhoto`, `createdAt`, and `updatedAt`. `profilePhoto` is `null` when no
photo has been uploaded; otherwise it is a URL path such as
`/uploads/profile-photos/<filename>.png`. Display the image using
`${API_BASE_URL}${profilePhoto}`.

### Update profile fields

`PUT /api/v1/users/profile`

Send one or more of these optional fields. Unknown fields are rejected.

```json
{
  "fullName": "Rahul Kumar",
  "phoneNumber": "+919876543210",
  "email": "rahul@example.com",
  "gender": "male",
  "dob": "1998-05-20"
}
```

At least one field is required. `dob` must be a valid past date in `YYYY-MM-DD`
format. Profile photo is updated separately.

### Update profile photo

`PATCH /api/v1/users/profile/photo`

Send `multipart/form-data` with a single file field named `profilePhoto`. Accepted
formats are JPEG, PNG, and WebP; maximum size is 5 MB. Do not manually set the
multipart `Content-Type` header in browser `fetch`; the browser must add the boundary.
Uploading a new photo replaces the old file and profile path.

Example:

```js
const form = new FormData();
form.append('profilePhoto', file);

const response = await fetch(`${API_BASE_URL}/api/v1/users/profile/photo`, {
  method: 'PATCH',
  headers: {
    Authorization: `Bearer ${accessToken}`,
  },
  body: form,
});
```

## Finance APIs

All finance routes require `Authorization: Bearer <accessToken>`. Master lists are
private to the logged-in user. Create the required masters first and use their returned
IDs when creating transactions.

### Finance masters

The same operations are available for each resource:

| Resource | Collection path |
|---|---|
| Expense types | `/api/v1/transactions/expense-types` |
| Income types | `/api/v1/transactions/income-types` |
| Payment modes | `/api/v1/transactions/payment-modes` |

| Method | Path | Purpose |
|---|---|---|
| `GET` | collection path | List the current user's records |
| `POST` | collection path | Create a record |
| `PATCH` | collection path `/{id}` | Update one or more fields |
| `DELETE` | collection path `/{id}` | Delete an unused record |

Create request:

```json
{
  "name": "Food",
  "description": "Meals and groceries"
}
```

`name` is required (1-80 characters); `description` is optional (up to 200 characters).
Update accepts either field but requires at least one. Names must be unique per user.
Deleting a master referenced by a transaction returns `409 Conflict`.
Master records are returned as MongoDB documents; use the returned `_id` as the
`expenseTypeId`, `incomeTypeId`, or `paymentModeId` in transaction requests. List
responses have an array in `data`; create and update responses have one record in
`data`.

### Transactions

#### Create

`POST /api/v1/transactions`

Expense request:

```json
{
  "type": "expense",
  "expenseTypeId": "EXPENSE_TYPE_ID",
  "paymentModeId": "PAYMENT_MODE_ID",
  "amount": 125.5,
  "transactionDate": "2026-10-15",
  "note": "Groceries"
}
```

Income request uses `type: "income"` and `incomeTypeId` instead of `expenseTypeId`:

```json
{
  "type": "income",
  "incomeTypeId": "INCOME_TYPE_ID",
  "paymentModeId": "PAYMENT_MODE_ID",
  "amount": 25000,
  "transactionDate": "2026-10-15T09:30:00+05:30",
  "note": "Salary"
}
```

`amount` is a positive INR number with at most two decimal places. `transactionDate`
accepts `YYYY-MM-DD` or an ISO datetime with timezone offset. `note` is optional, up to
500 characters. Use only the master ID appropriate for the selected `type`; all IDs
must belong to the authenticated user.

Successful create returns `201 Created`. Transaction data includes `id`, `type`,
`expenseTypeId`, `incomeTypeId`, `paymentModeId`, `amount`, `currency` (`"INR"`),
`transactionDate`, `note`, `createdAt`, and `updatedAt`. The unused type-specific ID
is returned as `null`.

#### List and month filter

`GET /api/v1/transactions`

Optional query parameter:

```text
?month=2026-10
```

Month format is `YYYY-MM`. Without it, the API returns all of the user's transactions.
Results are sorted newest first. The response `data` is an array.

#### Update

`PATCH /api/v1/transactions/{transactionId}`

Send one or more transaction fields from the create request. Only supplied fields are
changed; the backend checks the resulting transaction as a whole. When changing
`type`, include the matching new type-specific master ID. The previous type-specific
master reference is cleared automatically.

#### Delete

`DELETE /api/v1/transactions/{transactionId}`

No body is required. Success response data is `{}`.

### Monthly summary and all-time balance

`GET /api/v1/transactions/summary`

Optional query: `?month=2026-10`. If omitted, the current UTC month is selected.

Example response data:

```json
{
  "month": "2026-10",
  "monthlyIncome": 25000,
  "monthlyExpense": 125.5,
  "monthlyBalance": 24874.5,
  "totalIncome": 50000,
  "totalExpense": 10000,
  "totalBalance": 40000,
  "currency": "INR",
  "months": [
    {
      "month": "2026-10",
      "income": 25000,
      "expense": 125.5,
      "balance": 24874.5,
      "currency": "INR"
    }
  ]
}
```

Monthly and all-time totals are calculated from transactions; the frontend does not
need to submit or maintain a separate monthly-total record.

## Common status codes

| Status | Meaning |
|---|---|
| `200` | Request succeeded |
| `201` | Record created |
| `400` | Invalid request, field value, ID, or month |
| `401` | Missing/invalid access token or invalid/expired refresh token |
| `404` | Requested user, master, or transaction was not found |
| `409` | Duplicate master name or attempt to delete a master in use |
| `413` | Request body or profile photo exceeds its size limit |
| `501` | Endpoint is not implemented (OTP currently) |
| `500` | Unexpected server error |

## API explorer

The backend also serves Swagger UI at `/api-docs` and the OpenAPI JSON document at
`/api-docs.json` on the backend origin.
